import java.util.*;
public class postordernorecurrsion
{
	public static class Node
	{
		int data;
		Node right;
		Node left;
		Node(int data)
		{
			this.data=data;
			right=left=null;
		}
	}
	
	public static void postoder(Node root)
	{
		if(root==null)
		{
			return;
		}
		Stack<Node> s1=new Stack<>();
		Stack<Node> s2=new Stack<>();
		s1.push(root);
		while(!s1.isEmpty())
		{
			Node t=s1.pop();
		    s2.push(t);
			if(t.right !=null)
			{
				s1.push(t.right);
			}
			if(t.left !=null)
			{
				s1.push(t.left);
			}
		}
		while(!s2.isEmpty())
		{
			System.out.println(s2.peek().data);
			s2.pop();
		}
	}
	
	public static void main(String args[])
	{
		postordernorecurrsion p=new postordernorecurrsion();
		Node n=new Node(1);
		n.right=new Node(3);
		n.left=new Node(2);
		postoder(n);
	}
}