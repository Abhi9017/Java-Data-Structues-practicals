public class add{
public static void main (String args[]){
	int c,a,b;
	
	b=5;
	
	System.out.println(b--);
	System.out.println(b);
	System.out.println(--b);
}}