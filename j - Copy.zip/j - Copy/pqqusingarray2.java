import  java.util.Scanner;
public class pqqusingarray2
{
	public static class PriorityQueue
	{ 
	
	static Scanner sc=new Scanner(System.in);
	
	static int s=sc.nextInt();
	static int arr[]=new int[s];
	static int top=-1;
	void add()
	{
		for(int i=0;i<s;i++)
		{
		System.out.println("enter"+i+"element");
		top++;
		arr[i]=sc.nextInt();
		}
		
		for(int k=0;k<s;k++)
		{
			for(int h=0;h<s-1-k;h++)
			{
				if(arr[h]>arr[h+1])
				{
					int temp=arr[h];
					arr[h]=arr[h+1];
					arr[h+1]=temp;
				}
			}
		}
		
		
	}
	
	public static void poll()
	{
		int polled=arr[0];
		for(int i=0;i<s-1;i++)
		{
			arr[i]=arr[i+1];
		}
		s--;
		System.out.println(polled+" "+"poll");
	}
	
	public static void peek()
	{
		
		
		System.out.println(arr[0]+"is "+"peek element");
	}
		
		public static void print()
		{
			for(int i=0;i<s;i++)
			{
				System.out.println(arr[i]);
			}
		}
	}
	
	public static void main(String args[])
	{
		
		PriorityQueue pq=new PriorityQueue();
		pq.add();
		pq.print();
		pq.poll();
		pq.print();
		pq.peek();
		
	}
}









/**/