import java.util.*;
public class postoederrecur
{
	public static class Node
	{
		int data;
		Node left,right;
		Node(int data)
		{
			this.data=data;
			left=right=null;
		}
	}
	
	public static void postorder(Node root)
	{
		if(root==null)
		{
			return;
		}
		
		postorder(root.left);
		postorder(root.right);
		
		System.out.print(root.data);
	}
	public static void main(String  args[])
	{
		postoederrecur p=new  postoederrecur();
		Node n=new Node(1);
		n.left=new Node(2);
			n.left.left=new Node(4);
				n.left.right=new Node(5);
		n.right=new Node(3);
		postorder(n);
		
	}
}