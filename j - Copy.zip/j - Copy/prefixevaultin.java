import java.util.*;
public class prefixevaultin
{
	static Stack<Integer> s=new Stack<>();
	public static void convert(String expre)
	{
		for(int i=expre.length()-1;i>=0;i--)
		{
			char ch=expre.charAt(i);
			if(Character.isDigit(ch))
			{
				s.push(ch -'0');
			}
			else
			{
				int y=s.pop();
				int x=s.pop();
				switch(expre.charAt(i))
				{
					case'+':
					s.push(x+y);
					break;
					case'-':
					s.push(x-y);
					break;
					case'*':
					s.push(x*y);
					break;
					case'/':
					s.push(x/y);
					break;
					case'^':
					s.push(x^y);
					break;
				}
				}
		}
		System.out.print(s.peek());
	}
	public static void main(String args[])
	{
		String s="/22";
		convert(s);
	}
}