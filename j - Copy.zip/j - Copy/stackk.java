public class stackk{
	int top=-1;
	
	
	public static void main(String args[]){
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(8);
		al.add(8);
		al.add(8);
		al.add(8);
		System.out.print(al.get(0));
	}
	}
