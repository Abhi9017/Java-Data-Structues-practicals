public class stackusingnodes{
	public static class Node{
	  int data;
	  Node next;
	  Node(int data){
		  this.data=data;
		  next=null;
	  }
	}
	public static class stack{
		public static Node head;
		
		public static Boolean isEmpty(){
			return head==null;
		}
		
		public static void push(int data){
			 Node n= new Node(data);
			if(isEmpty()){
				head=n;
			
			}
			head.next=n;
			head=n;
		}
		
		
		public static int pop(){
			if(isEmpty()){
				return -1;
			}
			int top = head.data;
            head=head.next;
			System.out.print("poped " +top);
			return top;
			
		}
		public static  int peek(){
			if(isEmpty()){
				return -1;
			}
			System.out.print(head.data);
			return head.data;
		}
		public static void main(String args[]){
			stackusingnodes ss=new stackusingnodes();
			stack s=new stack();
			s.push(1);
			s.push(2);
			s.push(3);
			s.push(4);
			s.pop();
			s.peek();
		}
		
	}
	
	
	
	
	
}