import java.util.Stack;
public class preordernorecursion
{
	public static class Node
	{
        int data;
		Node right;
		Node left;
		Node(int data)
		{
			this.data=data;
			right=null;
			left=null;
		}
	}
	
	
public static void   preordernorecursion()

{
	Node root=null;
}
	
	public static void main(String args[])
	{
		
		preordernorecursion p=new preordernorecursion();
		p.root=new Node(1);
		
		
	}
	
}