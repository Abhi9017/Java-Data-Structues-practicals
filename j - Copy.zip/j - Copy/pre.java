import java.util.*;
public class pre

{
	public static class Node
	{
		int data;
		Node left,right;
		Node(int data)
		{
			this.data=data;
			left=right=null;
		}
	}
	
	public static void preorder(Node root)
	{
		if(root==null)
		{
			return;
		}
		Stack<Node> s=new Stack<>();
		s.push(root);
		while(!s.isEmpty())
		{
			Node t=s.pop();
			System.out.println(t.data);
			if(t.right !=null)
			{
				s.push(t.right);
			}
			if(t.left !=null)
			{
				s.push(t.left);
			}
		}
		
	}
	public static void main(String args[])
	{
		pre p=new pre();
		Node n=new Node(1);
		n.left=new Node(2);
		n.right=new Node(3);
		p.preorder(n);
	}
}
