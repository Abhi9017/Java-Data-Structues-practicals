import java.util.*;
public class prefixtopostfix
{
	static Stack<String> s=new Stack<>();
	public static Boolean checkoperAND(char ch)
	{
		return (ch>='a' && ch<='z' || ch>='A' && ch<='Z');
	}
	
	public static void convert(String expre)
	{
		for(int i=expre.length()-1;i>=0;i--)
		{
		if(checkoperAND(expre.charAt(i)))
		{
			s.push(expre.charAt(i)+"");
		}
		else
		{
			String y=s.peek();
			s.pop();
			String x=s.peek();
			s.pop();
			s.push(x+y+expre.charAt(i));  //s.push(x+expre.chart(i)+y);------->get prefix to infix
		}
	}
	
	  StringBuffer sb=new StringBuffer(s.pop());
		System.out.print(sb.reverse());
	
	}
	
	
	public static void main(String args[])
	{
		String s="*+ab-cd";
        convert(s);
	}
}